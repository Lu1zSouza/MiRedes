/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoclienteautorama.model;

import java.io.Serializable;

/**
 *
 * @author Luiz
 */
public class Pista implements Serializable{
    private String id, nome, pais, tempo_minimo, record_pista;
    private Piloto nome_recordista;
    
    public Pista(String id, String nome, String pais, String tempo_minimo, String record_pista, Piloto nome_recordista){
        this.id = id;
        this.nome = nome;
        this.pais = pais;
        this.tempo_minimo = tempo_minimo;
        this.record_pista = record_pista;
        this.nome_recordista = nome_recordista;
    }
    
    public Pista(String id, String nome, String pais, String tempo_minimo){
        this.id = id;
        this.nome = nome;
        this.pais = pais;
        this.tempo_minimo = tempo_minimo;
        this.record_pista = "Não houve";
        this.nome_recordista = null;
    }
    
    public void setId(String id){
        this.id = id;
    }
    
    public String getId(){
        return id;
    }
    
    public void setNome(String nome){
        this.nome = nome;
    }
    
    public String getNome(){
        return nome;
    }
    
    public void setPais(String pais){
        this.pais = pais;
    }
    
    public String getPais(){
        return pais;
    }
    
    public void setTempo_Minimo(String tempo_minimo){
        this.tempo_minimo = tempo_minimo;
    }
    
    public String getTempo_Minimo(){
        return tempo_minimo;
    }
    
    public void setRecord_Pista(String record_pista){
        this.record_pista = record_pista;
    }
    
    public String getRecord_Pista(){
        return record_pista;
    }
    
    public void setNome_Recordista(Piloto nome_recordista){
        this.nome_recordista = nome_recordista;
    }
    
    public Piloto getNome_Recordista(){
        return nome_recordista;
    }
    
    @Override
    public String toString(){
        return id + "," + nome + "," + pais + "," + tempo_minimo + "," + record_pista + "," + nome_recordista;
    }
    
}