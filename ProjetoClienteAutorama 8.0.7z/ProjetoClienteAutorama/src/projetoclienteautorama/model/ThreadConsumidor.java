/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoclienteautorama.model;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONObject;
import projetoclienteautorama.controller.Talk;

/**
 *
 * @author Luiz
 */
public class ThreadConsumidor implements Runnable{
    Talk talk;
    public BufferedReader input;
    public boolean online = false;
    public JSONObject msg;
    
    public ThreadConsumidor() {
        
    }
    
    @Override
    public void run() {
        
        while(online){
            
            try {
                String chegou = input.readLine();
                if(chegou != null){
                    msg = new JSONObject(chegou);
                    talk = Talk.getInstance();
                    talk.recebeMensagem(msg);
                }
            } catch (IOException ex) {
                Logger.getLogger(ThreadConsumidor.class.getName()).log(Level.SEVERE, null, ex);
                System.out.println(ex);
            }
            System.out.println("Rodando");
        }
    }
    
    public void start(BufferedReader e){
        if(!online){
            input = e;
            this.online = true;
            new Thread(this).start();
        }
        
    }
    
    public void stop(){
        this.online = false;        
    }
    
}
