/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoclienteautorama.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONObject;
import projetoclienteautorama.model.Carro;
import projetoclienteautorama.model.Equipe;
import projetoclienteautorama.model.Piloto;
import projetoclienteautorama.model.Pista;
import projetoclienteautorama.view.Cadastro;
import projetoclienteautorama.view.TalkServidor;
import projetoclienteautorama.view.TelaInicial;

/**
 *
 * @author Luiz
 */
public class Settings {
    
    /*
    public Comunication comunicacao = Comunication.getInstance();
    public GerenciadorBD bancoDados = GerenciadorBD.getInstance();
    
    public Corrida corrida = Corrida.getInstance();
    
    public Principal telaPrincipal;
    public TelaInicial telaInicial = new TelaInicial();
    public Cadastro telaCadastro = new Cadastro();
    public ConfiguraCorrida telaConfig;
    public Qualificatorio telaQuali;
    public Corrida telaCorrida;
    public ApertouBotao telaBotao;
    public int flag = 2;
    */
    
    
    
    
    public Talk talk = Talk.getInstance();
    public DB bancoDados = DB.getInstance();
    
    public TelaInicial telaInicial = new TelaInicial();
    public TalkServidor talkServidor = new TalkServidor();
    public Cadastro telaCadastro = new Cadastro();
    public TalkServidor telaTalkServidor;
    public int sinal = 2; //Controlar a serialização
    
    //public ConfiguraCorrida telaConfig; //Não fiz
    //public Qualificatorio telaQuali; //Não fiz
    //public TelaCorrida telaCorrida; //Não fiz
    //public ApertouBotao telaBotao; //Não fiz
    //public Semaphore semaforo; //Não fiz
    
    //public File config_Inicial;
    
    
    private Settings(){
        
    }
    
    private static Settings instancia = new Settings();
    
    public static Settings getInstance(){
        return instancia;
    }
    
    public void configInicialRasp(String ip, String porta, String portaSerial, String baudrate, String regiao, String antena, String protocolo, String power){
        
        talk.conexaoCliente(ip, porta);
        talk.threadConsumidor.start(talk.input);
        talk.POSTconfigRasp(portaSerial, baudrate, regiao, antena, protocolo, power);
    }

    public int cadCarro(String EPC, String numero, String modelo, String marca, String cor){
        Carro newCarro = new Carro(EPC, numero, modelo, marca, cor);
        return bancoDados.saveCarro(newCarro);
    }
    public int cadPiloto(String id, String nacionalidade, String nome, String apelido, String dtNascimento) {
        Piloto newPiloto = new Piloto(id, nacionalidade, nome, apelido, dtNascimento);
        return bancoDados.savePiloto(newPiloto);
    }
    
    public int cadEquipe(String id, String nacionalidade, String nome, String ano, String apelido){
        Equipe newEquipe = new Equipe(id, nacionalidade, nome, ano, apelido);
        return bancoDados.saveEquipe(newEquipe);
    }
    
    public int cadPista(String id, String nome, String pais, String tempo_minimo){
        Pista newPista = new Pista(id, nome, pais, tempo_minimo);
        return bancoDados.savePista(newPista);
    }
    
    public int cadastrarPilotoNoCarro(String IdPiloto, String IdCarro){
        return bancoDados.savePilotoNoCarro(IdPiloto, IdCarro);
    }
    
     public JSONObject getEPC() {
        return talk.getEPC();
    }
    public void setTelaInicial(TelaInicial telaInicial){
        this.telaInicial = telaInicial;
    }
    
    public void abrirTelaInicial(){
        telaInicial.setEnabled(true);
        telaInicial.setVisible(true);
    }
    
    public void setTelaTalkServidor(TalkServidor teTalkServidor){
        this.telaTalkServidor = teTalkServidor;
    }
    
    public void abrirTalkServidor(){
        telaInicial.setEnabled(false);
        telaInicial.setVisible(false);
        talkServidor = new TalkServidor();
        talkServidor.setLocationRelativeTo(talkServidor);
        talkServidor.setEnabled(true);
        talkServidor.setVisible(true);
    }
    
    public void abrirTelaCadastro(Cadastro telaCadastro){
        telaInicial.setEnabled(false);
        telaInicial.setVisible(false);
        telaCadastro.setLocationRelativeTo(telaInicial);
        telaCadastro.setEnabled(true);
        telaCadastro.setVisible(true);
    }
    
    public void setTelaCadastro(Cadastro telaCadastro){
        this.telaCadastro= telaCadastro;
    }
    
    public void fecharTelaInicialDeCadastro(){
        telaCadastro.setEnabled(false);
        telaCadastro.setVisible(false);
        sinal = bancoDados.desserializacaoCarros();
        telaInicial.setLocationRelativeTo(telaCadastro);
        telaInicial.setEnabled(true);
        telaInicial.setVisible(true);
    }
    public int salvarCadastroCarro(){
        return bancoDados.serializacaoCarros();
    }
    
    public void fecharPrograma(){
        System.exit(0);
    }
}