/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//ssh pi@augusto.ddns.net -p 2222 8222 autorama
//Python3 Servidor.py
//Porta Luiz 5027
//Porta Jairo/ Luiz 5029
package projetoclienteautorama.controller;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONObject;
import projetoclienteautorama.model.ThreadConsumidor;

/**
 *
 * @author Luiz
 */
public class Talk {
    
    public static Socket cliente;
    public String ip;
    public int porta;
    public JSONObject jsonRecebido = new JSONObject();
    public boolean online = false;
    public BufferedWriter output;
    public BufferedReader input;
    public ThreadConsumidor threadConsumidor = new ThreadConsumidor();
    
    public Talk(){
        
    }
    
    private static Talk Instancia = new Talk();
    
    public static Talk getInstance(){
        return Instancia;
    }
    
    public void conexaoCliente(String ip, String portaServidor){
        try {
        this.ip = ip;
        //int porta = portaServidor;
        this.porta = Integer.parseInt(portaServidor);
        //ip = augusto.ddns.net porta=2222
        cliente = new Socket(ip, porta);
        //cliente = new Socket("augusto.ddns.net", 5021);
        
        output = new BufferedWriter(new OutputStreamWriter(cliente.getOutputStream()));
        input = new BufferedReader(new InputStreamReader(cliente.getInputStream()));
        System.out.println("Conexão Ok");
        } catch (IOException ex) {
            Logger.getLogger(Talk.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro na conexão: " + ex);
        }
    }
    
    public void POSTconfigRasp(String portaSerial, String baudrate, String regiao, String antena, String protocolo, String power){
        
        JSONObject configRasp = new JSONObject();
        
        configRasp.put("METODO", "POST"); //GET
        configRasp.put("URL", "configRasp");
        configRasp.put("portaSerial", portaSerial);
        configRasp.put("baudrate", baudrate);
        configRasp.put("regiao", regiao);
        configRasp.put("antena", antena);
        configRasp.put("protocolo", protocolo);
        configRasp.put("power", power);
        
        try {
            output.write(configRasp.toString());
            output.flush();
        } catch (IOException ex) {
            Logger.getLogger(Talk.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /*public void retornoServidor(){
        try {
            BufferedReader recebeu = new BufferedReader (new InputStreamReader(cliente.getInputStream()));
            String s = recebeu.readLine();
            System.out.println(s);
        } catch (IOException ex) {
            Logger.getLogger(Talk.class.getName()).log(Level.SEVERE, null, ex);
        }
    }*/
    
    public void recebeMensagem(JSONObject msg){
        if(msg != null){
            this.jsonRecebido = msg;
        } else {
            System.out.println("null");
        }
        
    }    
    
    public JSONObject getEPC(){
        JSONObject getepc = new JSONObject();
        //getepc.put("METODO", "GET");
        //getepc.put("URL", "dadosEPC");
        System.out.println("passei 1");
        getepc.put("METODO", "GET");
        System.out.println("passei 2");
        getepc.put("URL", "lerTagCadastroCarro");
        System.out.println("passei 3");
        try{
            output.write(getepc.toString());
            //output.write("GET".toString());
            output.flush();
        } catch(IOException ex){
            Logger.getLogger(Talk.class.getName()).log(Level.SEVERE, null, ex);
        }
        while(!jsonRecebido.has("EPC0"))
        {
            //System.out.println("Eu");
            System.out.println(jsonRecebido.has("EPC0"));
        }                
        System.out.println("passei 4");
        return jsonRecebido;
    }
    
    /**
     * Método responsável por possibilitar que clientes entrem no processo de atendimento.
     * @param cliente Refere-se ao cliente.
     */
    
    public static void main(String[] args) {
        /*Talk instancia = Talk.getInstance();
        instancia.conexaoCliente("ip", "porta");
        System.out.println("Foi");
        //instancia.POSTconfigRasp("tmr:///dev/ttyUSB0", "230400", "NA2", "1", "GEN2", "1500");
        //instancia.POSTconfigRasp("portaSerial", "baudrate", "regiao", "antena", "protocolo", "power");
        System.out.println("enviou");
        try {
            BufferedReader recebeu = new BufferedReader (new InputStreamReader(cliente.getInputStream()));
            String s = recebeu.readLine();
            System.out.println(s);
        } catch (IOException ex) {
            Logger.getLogger(Talk.class.getName()).log(Level.SEVERE, null, ex);
        }*/
    }   
}
