/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoclienteautorama.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import projetoclienteautorama.model.Carro;
import projetoclienteautorama.view.TalkServidor;
import projetoclienteautorama.view.TelaInicial;

/**
 *
 * @author Luiz
 */
public class Settings {
    
    public Talk talk = Talk.getInstance();
    public TelaInicial telaInicial = new TelaInicial();
    public TalkServidor talkServidor = new TalkServidor();
    public TalkServidor telaTalkServidor;
    
    public File config_Inicial;
    public DB bancoDados = DB.getInstance();
    
    private Settings(){
        
    }
    
    private static Settings instancia = new Settings();
    
    public static Settings getInstance(){
        return instancia;
    }
    
    public void configInicialRasp(String ip, String porta, String portaSerial, String baudrate, String regiao, String antena, String protocolo, String power){
        
        talk.conexaoCliente(ip, porta);
        talk.POSTconfigRasp(portaSerial, baudrate, regiao, antena, protocolo, power);
    }

    public int cadCarro(String EPC, String numero, String modelo, String marca, String cor){
        Carro newCarro = new Carro(EPC, numero, modelo, marca, cor);
        return bancoDados.saveCarro(newCarro);
    }
    
    public void abrirTelaInicial(){
        telaInicial.setEnabled(true);
        telaInicial.setVisible(true);
    }
    
    public void abrirTalkServidor(){
        telaInicial.setEnabled(false);
        telaInicial.setVisible(false);
        talkServidor = new TalkServidor();
        talkServidor.setLocationRelativeTo(talkServidor);
        talkServidor.setEnabled(true);
        talkServidor.setVisible(true);
    }
    
    public void setTelaTalkServidor(TalkServidor teTalkServidor){
        telaTalkServidor = teTalkServidor;
    }
    
    public int salvarCadastroCarro(){
        return bancoDados.serializacaoCarros();
    }
}
