/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoclienteautorama.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import projetoclienteautorama.model.Carro;
import projetoclienteautorama.model.Equipe;
import projetoclienteautorama.model.Piloto;
import projetoclienteautorama.model.Pista;

/**
 *
 * @author Ti
 */
public class DB {
    public File configInicial;
    public File carros = new File("db\\Carros.Autorama");
    public File pilotos = new File("db\\Pilotos.Autorama");
    public File equipes = new File("db\\Equipes.Autorama");
    public File pistas = new File("db\\Pistas.Autorama");
    public ArrayList<Carro> db_Carros = new ArrayList<Carro>();
    public ArrayList<Piloto> db_Pilotos = new ArrayList<Piloto>();
    public ArrayList<Equipe> db_Equipes = new ArrayList<Equipe>();
    public ArrayList<Pista> db_Pistas = new ArrayList<Pista>();
    
    private DB(){
    
    }
    
    private static DB instancia = new DB();
    
    public static DB getInstance(){
        return instancia;
    }
    
    public int saveCarro(Carro carro){
        for(int i = 0; i<db_Carros.size(); i++){
            if(db_Carros.get(i).getEPC().equals(carro.getEPC())){
                return 1; //EPC já está no banco de dados
            } 
            if(db_Carros.get(i).getNumero().equals(carro.getNumero())){
                return 2; //Númro já existe
            }
        }
        db_Carros.add(carro);
        return 0;
    }
    
    public int serializacaoArquivos(){
        if(carros.exists()){
            carros.delete();
        }
        if(pilotos.exists()){
            pilotos.delete();
        }
        if(equipes.exists()){
            equipes.delete();
        }
        if(pistas.exists()){
            pistas.delete();
        }
        try{
            carros.createNewFile();
            FileOutputStream fileOutput = new FileOutputStream(carros);
            ObjectOutputStream objOutput = new ObjectOutputStream(fileOutput);
            objOutput.writeObject(db_Carros);
            objOutput.close();
            objOutput.flush();
            
            pilotos.createNewFile();
            fileOutput = new FileOutputStream(pilotos);
            objOutput = new ObjectOutputStream(fileOutput);
            objOutput.writeObject(db_Pilotos);
            objOutput.close();
            objOutput.flush();
            
            equipes.createNewFile();
            fileOutput = new FileOutputStream(equipes);
            objOutput = new ObjectOutputStream(fileOutput);
            objOutput.writeObject(db_Equipes);
            objOutput.close();
            objOutput.flush();
            
            pistas.createNewFile();
            fileOutput = new FileOutputStream(pistas);
            objOutput = new ObjectOutputStream(fileOutput);
            objOutput.writeObject(db_Pistas);
            objOutput.close();
            objOutput.flush();
            
            } catch (IOException ex) {
                Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
            }
        return 0;
        }
    
    public int serializacaoCarros(){
        if(carros.exists()){
            carros.delete();
        }
        try{
            carros.createNewFile();
            FileOutputStream fileOutput = new FileOutputStream(carros);
            ObjectOutputStream objOutput = new ObjectOutputStream(fileOutput);
            objOutput.writeObject(db_Carros);
            objOutput.close();
            objOutput.flush();
        } catch (IOException ex) {
                Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
            }
        return 0;
    }
    
    public int desserializacaoCarros(){
        ObjectInputStream objInput;
        try{
            if(carros.exists()){
                objInput = new ObjectInputStream(new FileInputStream(carros));
                db_Carros = (ArrayList<Carro>)objInput.readObject();
            } else{
                return 1; //Se deu ruim
            }
            } catch (IOException ex) {
            Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
            }catch(ClassNotFoundException ex){
            Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
            }
        return 0; // Deu certo
    }
}
