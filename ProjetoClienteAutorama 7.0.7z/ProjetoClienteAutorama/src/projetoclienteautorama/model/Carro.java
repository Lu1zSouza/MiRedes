/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoclienteautorama.model;

import java.io.Serializable;

/**
 *
 * @author Luiz
 */
public class Carro implements Serializable{
    
    private String EPC, numero, modelo, marca, cor;
    private Equipe equipe;
    private Piloto piloto;
    
    public Carro(){
        
    }
    
    
    public Carro(String EPC, String numero){
        this.EPC = EPC;
        this.numero = numero;
    }
    public Carro(String EPC, String numero, Equipe equipe, Piloto piloto){
        this.EPC = EPC;
        this.numero = numero;
        this.equipe = equipe;
        this.piloto = piloto;
    }
    
    public Carro(String EPC, String numero, String modelo, String marca, String cor){
        this.EPC = EPC;
        this.numero = numero;
        this.modelo = modelo;
        this.marca = marca;
        this.cor = cor;
    }
    
    public void setEPC(String EPC){
        this.EPC = EPC;
    }
    
    public String getEPC(){
        return EPC;
    }
    
    public void setNumero(String numero){
        this.numero = numero;
    }
    
    public String getNumero(){
        return numero;
    }
    
    public void setMarca(String marca){
        this.marca = marca;
    }
    
    public String getMarca(){
        return marca;
    }
    
    public void setCor(String cor){
        this.cor = cor;
    }
    
    public String getCor(){
        return cor;
    }
    
    public void setModelo(String modelo){
        this.modelo = modelo;
    }
    
    public String getModelo(){
        return modelo;
    }
    public void setEquipe(Equipe equipe){
        this.equipe = equipe;
    }
    
    public Equipe getEquipe(){
        return equipe;
    }
    
    public void setPiloto(Piloto piloto){
        this.piloto = piloto;
    }
    
    public Piloto getPiloto(){
        return piloto;
    }
}
