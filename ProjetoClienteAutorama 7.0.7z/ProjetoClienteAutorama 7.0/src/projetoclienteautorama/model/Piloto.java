/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoclienteautorama.model;

import java.io.Serializable;

/**
 *
 * @author Luiz
 */
public class Piloto implements Serializable{
    
    private String id, nacionalidade, nome, apelido, dtNascimento;
    private Equipe equipe;
    private Carro carro;
    private int posicao;
    private float tempo_volta;
    private int qtde_voltas;
    
    public Piloto(){
        
    }
    
    public Piloto(String id, String nacionalidade, String nome, Equipe equipe, Carro carro){
        this.id = id;
        this.nacionalidade = nacionalidade;
        this.nome = nome;
        this.equipe = equipe;
        this.carro = carro;
    }
    
    public Piloto(String id, String nacionalidade, String nome) {
        this.id = id;
        this.nacionalidade = nacionalidade;
        this.nome = nome;
    }
    public Piloto(String id, String nacionalidade, String nome, String apelido, String dtNascimento) {
        this.id = id;
        this.nacionalidade = nacionalidade;
        this.nome = nome;
        this.apelido = apelido;
        this.dtNascimento = dtNascimento;
    }

    public void setId(String id){
        this.id = id;
    }
    
    public String getId(){
        return id;
    }
    
    public void setNacionalidade(String nacionalidade){
        this.nacionalidade = nacionalidade;
    }
    
    public String getNacionalidade(){
        return nacionalidade;
    }
    
    public void setNome(String nome){
        this.nome = nome;
    }
    
    public String getNome(){
        return nome;
    }
    
    public void setEquipe(Equipe equipe){
        this.equipe = equipe;
    }
    
    public Equipe getEquipe(){
        return equipe;
    }
    
    public void setCarro(Carro carro){
        this.carro = carro;
    }
    
    public Carro getCarro(){
        return carro;
    }
    
    public void setPosicao(int posicao){
        this.posicao = posicao;
    }
    
    public int getPosicao(){
        return posicao;
    }
    
    public void setTempo_Volta(float tempo_volta){
        this.tempo_volta = tempo_volta;
    }
    
    public float getTempo_Volta(){
        return tempo_volta;
    }
    
    public void setQtde_Voltas(int qtde_voltas){
        this.qtde_voltas = qtde_voltas;
    }
    
    public int getQtde_Voltas(){
        return qtde_voltas;
    }

    @Override
    public String toString() {
        return id + "," + nacionalidade + "," + nome + "," + equipe + "," + carro + "," + posicao + "," + tempo_volta + "," + qtde_voltas;
    }
    
    /*
    public Equipe to(){
        return equipe;
    }
    
    public Carro toCarro(){
        return carro;
    }
    */
    
}
