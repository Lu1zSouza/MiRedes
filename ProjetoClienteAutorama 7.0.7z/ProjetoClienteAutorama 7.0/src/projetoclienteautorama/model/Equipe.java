/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoclienteautorama.model;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Luiz
 */
public class Equipe implements Serializable{
    
    private String id, nacionalidade, nome, ano, apelido;
    private ArrayList<Carro> Carros;
    private ArrayList<Piloto> Pilotos;
    
    public Equipe(){
        
    }
    
    public Equipe(String id, String nacionalidade, String nome, String ano, String apelido){
        this.id = id;
        this.nacionalidade = nacionalidade;
        this.nome = nome;
        this.ano = ano;
        this.apelido = apelido;
    }
    
    public void setId(String id){
        this.id = id;
    }
    
    public String getId(){
        return id;
    } 
    
    public void setNacionalidade(String nacionalidade){
        this.nacionalidade = nacionalidade;
    }
    
    public String getNacionalidade(){
        return nacionalidade;
    }
    
    public void setNome(String nome){
        this.nome = nome;
    }
    
    public String getNome(){
        return nome;
    }
    
    public void setAno(String ano){
        this.ano = ano;
    }
    
    public String getAno(){
        return ano;
    }
    
    public ArrayList<Carro> getCarros(){
        return Carros;
    }
    
    public void addCarro(Carro Carro){
        this.Carros.add(Carro);
    }
    
    public ArrayList<Piloto> getPilotos(){
        return Pilotos;
    }
    
    public void addPiloto(Piloto Piloto){
        this.Pilotos.add(Piloto);
    }
}
