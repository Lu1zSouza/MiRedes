from datetime import datetime
import time

y3 = 0.0
largada = 0.0

class Carro:
    def __init__(self, nome, timestamp, contadorVoltasCarro):
        self.nome = nome
        self.timestamp = timestamp
        self.contadorVoltasCarro = contadorVoltasCarro

    def setNome(self, nome):
        self.nome = nome

    def setTimeStamp(self, timestamp):
        self.timestamp = timestamp

    def setContadorVoltasCarro(self, contadorVoltasCarro):
        self.contador = contadorVoltasCarro

    def getNome(self):
        return self.nome

    def gettimestamp(self):
        return self.timestamp

    def getContador(self):
        return self.contador

largada = 0.0
tempoMinimo = 10.0
contadorVoltasCarro1 = 0

c1 = "epc1"
c2 = "epc2"
c3 = "epc3"
ts1 = 11.0
ts2 = 12.0
ts3 = 13.0

list = []

def callBackRead(epc, timestamp):
    global largada    
    global tempoMinimo
    global contadorVoltasCarro1, contadorVoltasCarro2, contadorVoltasCarro3
    # tag = epc.decode("utf-8")
    tag = epc
    if(tag == "epc1"):
        if(timestamp - largada > tempoMinimo):            
            contadorVoltasCarro1 +=1
            list.append(Carro.setNome(tag), Carro.setTimeStamp(timestamp), Carro.setContadorVoltasCarro(contadorVoltasCarro1))
            #list.append(Carro.setNome(tag), Carro.setTimeStamp(timestamp), Carro.setContadorVoltasCarro(contadorVoltasCarro1)
            #list.append(Carro(tag, timestamp, contadorVoltasCarro1))
            print(tag, timestamp, contadorVoltasCarro1)
    if(tag == "epc2"):
        if(timestamp - largada > tempoMinimo):            
            contadorVoltasCarro2 +=1
            #list.append(Carro(tag, timestamp, contadorVoltasCarro1))
            list.append(Carro(tag, timestamp, contadorVoltasCarro2))
            print(tag, timestamp, contadorVoltasCarro2)
    if(tag == "epc3"):
        if(timestamp - largada > tempoMinimo):            
            contadorVoltasCarro3 +=1
            #list.append(Carro(tag, timestamp, contadorVoltasCarro1))
            list.append(Carro(tag, timestamp, contadorVoltasCarro3))
            print(tag, timestamp, contadorVoltasCarro3)

callBackRead(c1, ts1)
callBackRead(c2, ts2)
callBackRead(c3, ts3)
ts1 = 1.0
ts2 = 2.0
ts3 = 3.0
callBackRead(c1, ts1)
callBackRead(c2, ts2)
callBackRead(c3, ts3)
ts1 = 15.0
ts2 = 20.0
ts3 = 3.0
callBackRead(c1, ts1)
callBackRead(c2, ts2)
callBackRead(c3, ts3)


print("-----------------------------------------")

for obj in list:
    #print(obj.getNome, obj.gettimestamp, obj.getContador, sep =' ')
    print(obj.nome, obj.timestamp, obj.contadorVoltasCarro, sep =' ')
