#coding: utf-8

#== CLASSE ALUNO ==#
class Aluno():
    def __init__(self, nome, cpf):
        self.nome = nome # Atributo nome (ok)
        self.cpf = cpf[:3] + "." + cpf[3:6] + "." + cpf[6:9] + "-" + cpf[9:] # Atributo cpf (ok)

    def __str__(self):
        return "Nome: " + str(self.nome) + " - CPF: " + str(self.cpf)

# TESTE DA CLASSE ALUNO #
aluno_exemplo = Aluno("Joao","12345678901")
print aluno_exemplo


#== CLASSE EQUIPE ==#
class Equipe():
    def __init__(self, lista_de_alunos, projeto):
        self.lista_de_alunos = lista_de_alunos # Atributo lista de participantes (ok)
        self.projeto = projeto # Atributo projeto (ok)

    def __str__(self):
        return "Nome: " + str(self.lista_de_alunos) + " - Projeto: " + str(self.projeto)

# TESTE DA CLASSE EQUIPE #
equipe_exemplo = Equipe([aluno_exemplo, Aluno("Maria","12345257901")], "Projeto Abacaxi") # Apenas com dois alunos para facilitar a vida :D
print equipe_exemplo