#coding: utf-8

#== CLASSE ALUNO ==#

#Adicionar quantidade de alunos usando vetor

quantidadeAlunos = input ("Informe a quantidade de alunos participantes: ")  ### Não precisa dessa variável para o problema

numAlunos = quantidadeAlunos ### Não precisa dessa variável
nomes = [] ### Não precisa dessa lista (ou array)
cpfs = [] ### Não precisa dessa lista

#Classe aluno
class Aluno():
    #Atributos
    nome = input ("Insira seu nome: ") ### Fazer um input dentro de uma classe me parece deselegante. Eu não faria isso. Até porque a questão não pede. Depois eu te mostro uma maneira melhor para você conseguir testar se está funcionando.
    cpf = input ("Insira seu cpf: ") ### Mesma coisa que o de cima

    #Métodos
    def __init__(self, nome = nome, cpf = cpf): ### Aqui vc pode colocar def __init__(self, nome, cpf):   caso vc tire os inputs de cima
        self.nome = nome
        self.cpf = cpf[:3] + "." + cpf[3:6] + "." + cpf[6:9] + "-" + cpf[9:]

    #def printAluno(self):
    #   print ("Nome: %s - CPF: %s" % (self.nome, self.cpf))

p = Aluno() ### Aqui, para instanciar um objeto Aluno, vc deverá passar como argumento os atributos nome e cpf, dessa forma: p = Aluno("joãozinho", "16734624789")   caso você tire os inputs também.
p.printAluno()

#== CLASSE EQUIPE ==#

class Equipe():
    nome = input ("Insira seu nome: ") ### Mesmo argumento da classe anterior
    cpf = input ("Insira seu cpf: ") ### Mesmo argumento

    def __init__(self, nome = nome, cpf = cpf): ### Aqui é o pulo do gato. Você deve receber uma lista (de alunos) e um projeto, então fica assim: def __init__(self, lista_de_alunos, projeto):
        self.nome = nome ### Aqui consequentemente fica: self.lista_de_alunos = lista_de_alunos
        self.cpf = cpf ### E a mesma coisa aqui para projeto: self.projeto = projeto

    def printAluno(self): ### Isso pode ser uma sobrecarga do operador print. Não é pedido no problema. Você pode fazer para conseguir printar o seu objeto no final, mas não vou entrar nesse detalhe. No código que eu fizer em baixo você vai ver um __str__(self), que é justamente o que esse cara faria.
        print ("Nome: %s - CPF: %s" % (self.nome, self.cpf))

### Aqui, para testes podemos criar uma lista de alunos assim: lista = [Aluno("Joao","123"),Aluno("Maria","145")]
### E podemos também criar um projeto assim: projeto = "lavar louça"
p = Aluno() ### Aqui você pode instanciar um objeto da classe Equipe dessa forma: equipe1 = Equipe(lista, projeto)
p.print.Aluno()

### Daqui para baixo deixo com você. Se você entender realmente o que fiz em cima, pode fazer o de baixo sozinho.
#== CLASSE GERENCIADOR DE EQUIPES ==#

class GerenciadorEquipes():
    nome = input ("Insira seu nome: ")
    cpf = input ("Insira seu cpf: ")

    def __init__(self, nome = nome, cpf = cpf):
        self.nome = nome
        self.cpf = cpf

    def printAluno(self):
        print ("Nome: %s - CPF: %s" % (self.nome, self.cpf))

p = Aluno()
p.printAluno()