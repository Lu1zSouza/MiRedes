from datetime import datetime
import time

y3 = 0.0
largada = 0.0

class Carro:
    def __init__(self, nome, timestamp, contadorVoltasCarro):
        self.nome = nome
        self.timestamp = timestamp
        self.contadorVoltasCarro = contadorVoltasCarro

largada = 0.0
tempoMinimo = 10.0
contadorVoltasCarro1 = 0

c1 = "epc1"
ts1 = 11.0

list = []

def callBackRead(epc, timestamp):
    global largada    
    global tempoMinimo
    global contadorVoltasCarro1, contadorVoltasCarro2, contadorVoltasCarro3
    # tag = epc.decode("utf-8")
    tag = epc
    if(tag == "epc1"):
        if(timestamp - largada > tempoMinimo):            
            contadorVoltasCarro1 +=1
            #list.append(Carro(setNome(tag), setTimeStamp(timestamp), setContadorVoltasCarro(contadorVoltasCarro1)))
            #list.append(Carro.setNome(tag), Carro.setTimeStamp(timestamp), Carro.setContadorVoltasCarro(contadorVoltasCarro1)
            list.append(Carro.nome(tag), Carro.timeStamp(timestamp), Carro.contadorVoltasCarro(contadorVoltasCarro1)
            print(tag, timestamp, contadorVoltasCarro1)

callBackRead(c1, ts1)
ts1 = 1.0
callBackRead(c1, ts1)
ts1 = 15.0
callBackRead(c1, ts1)

print("-----------------------------------------")

for obj in list:
    #print(obj.getNome, obj.gettimestamp, obj.getContador, sep =' ')
    print(obj.nome, obj.timestamp, obj.contadorVoltasCarro, sep =' ')