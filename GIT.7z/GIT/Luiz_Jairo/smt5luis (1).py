# -*- coding: utf-8 -*-
#!/usr/bin/env python3
from __future__ import print_function
import platform, subprocess, socket, sys, os, time, json
from datetime import datetime
import mercury
import _thread
import threading
import queue

reader = None
DNSname = "www.google.com"
queueAux = queue.Queue(maxsize=1000)
queueClassRace = queue.Queue(maxsize=1000)
podeLer = False
endClassRace = False
comecaDarVoltas = False
voltasInt = 0
contadorVoltas = 0
meucontador = 0
ServerSocket = socket.socket()
port = 5029 
host = '172.16.1.0'
# host = '192.168.0.10'
ThreadCount = 0
baudrate = 0
power = 0
regiao = ""
portaSerial = ""

try:
    ServerSocket.bind((host, port))
    print('Waitiing for a Connection..')
    ServerSocket.listen(5)
except socket.error as e:
    print(str(e))

def ct(host_or_ip, packets=1, timeout=1000):    
    if platform.system().lower() == 'windows':
        command = ['ping', '-n', str(packets), '-w', str(timeout), host_or_ip]        
        result = subprocess.run(command, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, creationflags=0x08000000)        
        return result.returncode == 0 and b'TTL=' in result.stdout
    else:
        command = ['ping', '-c', str(packets), '-w', str(timeout), host_or_ip]        
        result = subprocess.run(command, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return result.returncode == 0


def threaded_client(connection):
    global voltasInt    
    while True:

        pedido = connection.recv(2048).decode('utf-8')
        # listPedido = pedido.split("/")        
        print(pedido)
        dados_json = json.loads(pedido)

        if dados_json["METODO"] == 'POST':
            if dados_json["URL"] == 'configLeitor':
                recebeConfiguracao(dados_json)
                teste = "teste"
                _thread.start_new_thread(continuousReading, (teste, ))

        if dados_json["METODO"] == 'GET':
            if dados_json["URL"] == 'retornaEPC':
                sendTags()

            if dados_json["URL"] == 'comecaQual':
                voltasInt = int(dados_json["qtdVoltas"])
                tmVoltasI = int(dados_json["tmVoltas"])                
                print("pediu voltasInt = ", voltasInt)
                # time.sleep(5)
                # _thread.start_new_thread(qual, (voltasInt, voltasInt))            
                threading.Thread(target=qual, args=(voltasInt, voltasInt)).start()
                p = Pt(name='producer')
                c = Cp(name='consumer')
                p.start()
                c.start()
            
            if dados_json["URL"] == 'comecaCorr':
                voltasInt = int(dados_json["qtdVoltas"])
                print("pediu voltasInt = ", voltasInt)
                _thread.start_new_thread(race, (voltasInt, tmVoltasI))            
                p = Pt(name='producer')
                c = Cp(name='consumer')
                p.start()
                c.start()        


class Pt(threading.Thread):
    def __init__(self, group=None, target=None, name=None, args=(), kwargs=None, verbose=None):
        super(Pt,self).__init__()
        self.target = target
        self.name = name
        self._stop = threading.Event()
    def stop(self):
        self._stop.set()  
    def stopped(self):
        return self._stop.isSet()            
    def run(self):
        global queueClassRace
        global endClassRace
        global meucontador
        while True:            
            if not endClassRace or not queueClassRace.empty():
                queueAux.put(queueClassRace.get())
            if endClassRace and queueClassRace.empty():
                self.stop()
            if self.stopped():                
                return

class Cp(threading.Thread):
    def __init__(self, group=None, target=None, name=None, args=(), kwargs=None, verbose=None):
        super(Cp,self).__init__()
        self.target = target
        self.name = name
        self._stop = threading.Event()
        return
    def stop(self):
        self._stop.set()  
    def stopped(self):
        return self._stop.isSet()
    def run(self):
        global queueClassRace
        global endClassRace
        global meucontador        
        while True:            
            if not queueAux.empty():                
                # print(queueAux.get())
                dv = queueAux.get()
                while not ct(DNSname):
                    print("servidor foi desconectado")
                Client.send(dv.encode())
                print("ENVIOU PARA CLIENTE")
            if endClassRace and queueClassRace.empty() and queueAux.empty():
                self.stop()
            if self.stopped():                
                return

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
tagsTemp = {}

# def callBackRead(epc, timestamp):
#     global tagsTemp
#     tag = epc.decode("utf-8")
#     epcTimeStamp = timestamp        
#     auxValue = tagsTemp.get(tag) 
#     if auxValue == None:
#         tagsTemp[tag] = epcTimeStamp

def callBackRead(epc, timestamp):
    global largada    
    global tempoMinimo
    global contadorVoltasCarro1, contadorVoltasCarro2, contadorVoltasCarro3
    tag = epc.decode("utf-8")
    # tag = epc
    if(tag == "epc1"):
        if(timestamp - largada > tempoMinimo):            
            contadorVoltasCarro1 +=1
            print(tag, timestamp, contadorVoltasCarro1)
    if(tag == "epc2"):
        if(timestamp - largada > tempoMinimo):            
            contadorVoltasCarro2 +=1
            print(tag, timestamp, contadorVoltasCarro2)
    if(tag == "epc3"):
        if(timestamp - largada > tempoMinimo):            
            contadorVoltasCarro3 +=1
            print(tag, timestamp, contadorVoltasCarro3)


def continuousReading(teste):
    global podeLer
    global tagsTemp
    global comecaDarVoltas

    liberado = False

    while True:
        if podeLer and comecaDarVoltas:
            reader.start_reading(lambda tag: callBackRead(tag.epc, tag.timestamp))            
            time.sleep(0.250)            
            reader.stop_reading()
            print(podeLer)
            print("PRINT IF")
            print("\n")
            liberado = True            
        else:
            # print(podeLer)
            # print("\n")
            # print(tagsTemp)
            # print("\n")
            # if podeLer and comecaDarVoltas:
            print("podeLer = ", podeLer)
            print("liberado = ", liberado)
            if (podeLer == False) and (liberado == True):
                print("PRINT DENTRO")
                stringJSON = json.dumps(tagsTemp)
                queueClassRace.put(stringJSON)
                tagsTemp.clear()
                podeLer = True
                liberado = False

def aleatorio():
    # def qual(voltas, tempoMV):
    #     global queueClassRace
    #     global contadorVoltas    
    #     global endClassRace
    #     if endClassRace == True:
    #         endClassRace = False    
        
    #     allTags = {}
        
    #     while contadorVoltas < voltas:
    #         # time.sleep(tempoMV)
    #         print("voltas = ", voltasInt)
    #         print("contadorVoltas = ", contadorVoltas)

    #         nowtimestamp = datetime.timestamp(datetime.now())        
    #         # toList = reader.read(timeout=5000)
    #         toList = reader.read(timeout=tempoMV)        

    #         d = {}
    #         d["Referencia"] = nowtimestamp        
    #         print("\n")

    #         # if contadorVoltas == 0:
    #         #     for i in range(len(toList)):
    #         #         tag = toList[i].epc.decode("utf-8")
    #         #         epcTimeStamp = toList[i].timestamp
    #         #         d[tag] = epcTimeStamp
    #         #         allTags[tag] = epcTimeStamp
    #         # else:
    #         #     for i in range(len(toList)):
    #         #         tag = toList[i].epc.decode("utf-8")                
    #         #         # auxValue = allTags.get(tag)
    #         #         # if auxValue != None:
    #         #             # d.update({tag: toList[i].timestamp})        
    #         #         d[tag] = toList[i].timestamp
            
    #         tag = toList[i].epc.decode("utf-8")
    #         epcTimeStamp = toList[i].timestamp
    #         d[tag] = epcTimeStamp
    #         # allTags[tag] = epcTimeStamp
            
    #         for x, y in d.items():
    #             print(x, y)
    #         print("\n")
    #         # sl = sorted(d.items(), key=lambda x:x[1])
    #         # sd = dict(sl)        
    #         # ssd = json.dumps(sd)        
    #         # queueClassRace.put(ssd)        
    #         sc = json.dumps(d)        
    #         queueClassRace.put(sc)
    #         contadorVoltas += 1
    #         # print("COMPLETA = ", contadorVoltas, "\n")        
    #     endClassRace = True
    #     contadorVoltas = 0        
    #     # print("ACABOU classRAce LOOP")
    print()


# def com22():
def qual(voltas, tempoMV):
    global podeLer
    global tagsTemp
    global queueClassRace
    global contadorVoltas    
    global endClassRace
    global comecaDarVoltas
    if endClassRace == True:
        endClassRace = False    
    
    allTags = {}
    print("245")
    while contadorVoltas < voltas:
        comecaDarVoltas = True
        print("voltas = ", voltasInt)
        print("contadorVoltas = ", contadorVoltas)

        # nowtimestamp = datetime.timestamp(datetime.now())        
        
        time.sleep(tempoMV)
        if podeLer:
            print(podeLer)
            podeLer = False
            time.sleep(0.5)
            # na thread do leitor, desliga AUTOMATICAMENTE O leitor pelo IF
            # salvar na fila pelo ELSE
            # limpar dados pelo ELSE
            podeLer = True
        else:
            print("pode ler ELSE = ", podeLer)
            podeLer = True
                            # 1 -> 2 -> 3 -> 4 -> ... -> FINISH
        time.sleep(tempoMV)
        podeLer = False
        time.sleep(0.5)
        # na thread do leitor, desliga AUTOMATICAMENTE O leitor pelo IF
        # salvar na fila pelo ELSE
        # limpar dados pelo ELSE
        podeLer = True

        contadorVoltas += 1
        # print("COMPLETA = ", contadorVoltas, "\n")        
    endClassRace = True
    comecaDarVoltas = False
    podeLer = False
    contadorVoltas = 0        
    # print("ACABOU classRAce LOOP")
    # print()

def comqual():
    # def qual(voltas, tempoMV):
    #     global queueClassRace
    #     global contadorVoltas    
    #     global endClassRace
    #     if endClassRace == True:
    #         endClassRace = False    
        
    #     allTags = {}
        
    #     while contadorVoltas < voltas:
    #         print("voltas = ", voltasInt)
    #         print("contadorVoltas = ", contadorVoltas)

    #         nowtimestamp = datetime.timestamp(datetime.now())        
    #         # toList = reader.read(timeout=5000)
    #         toList = reader.read(timeout=tempoMV)

    #         d = {}
    #         d["Referencia"] = nowtimestamp        
    #         print("\n")

    #         if contadorVoltas == 0:
    #             for i in range(len(toList)):
    #                 tag = toList[i].epc.decode("utf-8")
    #                 epcTimeStamp = toList[i].timestamp
    #                 d[tag] = epcTimeStamp
    #                 allTags[tag] = epcTimeStamp
    #         else:
    #             for i in range(len(toList)):
    #                 tag = toList[i].epc.decode("utf-8")                
    #                 auxValue = allTags.get(tag)
    #                 if auxValue != None:
    #                     # d.update({tag: toList[i].timestamp})        
    #                     d[tag] = toList[i].timestamp
            
    #         for x, y in d.items():
    #             print(x, y)
    #         print("\n")
    #         # sl = sorted(d.items(), key=lambda x:x[1])
    #         # sd = dict(sl)        
    #         # ssd = json.dumps(sd)        
    #         # queueClassRace.put(ssd)        
    #         sc = json.dumps(d)        
    #         queueClassRace.put(sc)
    #         contadorVoltas += 1
    #         # print("COMPLETA = ", contadorVoltas, "\n")        
    #     endClassRace = True
    #     contadorVoltas = 0        
    #     # print("ACABOU classRAce LOOP")
    print("")


def race(voltas, tempoMV):
    global queueClassRace
    global contadorVoltas    
    global endClassRace
    if endClassRace == True:
        endClassRace = False    
    
    allTags = {}
    
    while contadorVoltas < voltas:
        time.sleep(tempoMV)
        print("voltas = ", voltasInt)
        print("contadorVoltas = ", contadorVoltas)

        nowtimestamp = datetime.timestamp(datetime.now())        
        # toList = reader.read(timeout=5000)
        toList = reader.read(timeout=tempoMV)        

        d = {}
        d["Referencia"] = nowtimestamp        
        print("\n")

        if contadorVoltas == 0:
            for i in range(len(toList)):
                tag = toList[i].epc.decode("utf-8")
                epcTimeStamp = toList[i].timestamp
                d[tag] = epcTimeStamp
                allTags[tag] = epcTimeStamp
        else:
            for i in range(len(toList)):
                tag = toList[i].epc.decode("utf-8")                
                auxValue = allTags.get(tag)
                if auxValue != None:
                    # d.update({tag: toList[i].timestamp})        
                    d[tag] = toList[i].timestamp
        
        for x, y in d.items():
            print(x, y)
        print("\n")
        # sl = sorted(d.items(), key=lambda x:x[1])
        # sd = dict(sl)        
        # ssd = json.dumps(sd)        
        # queueClassRace.put(ssd)        
        sc = json.dumps(d)        
        queueClassRace.put(sc)
        contadorVoltas += 1
        # print("COMPLETA = ", contadorVoltas, "\n")        
    endClassRace = True
    contadorVoltas = 0        
    # print("ACABOU classRAce LOOP")

def classRaceV2(voltas):
    global queueClassRace
    global contadorVoltas    
    global endClassRace
    if endClassRace == True:
        endClassRace = False    
    
    allTags = {}
    
    while contadorVoltas < voltas:
        print("voltas = ", voltasInt)
        print("contadorVoltas = ", contadorVoltas)

        nowtimestamp = datetime.timestamp(datetime.now())        
        toList = reader.read(timeout=5000)        

        d = {}
        d["Referencia"] = nowtimestamp        
        print("\n")

        if contadorVoltas == 0:
            for i in range(len(toList)):
                tag = toList[i].epc.decode("utf-8")
                epcTimeStamp = toList[i].timestamp
                d[tag] = epcTimeStamp
                allTags[tag] = epcTimeStamp
        else:
            for i in range(len(toList)):
                tag = toList[i].epc.decode("utf-8")                
                auxValue = allTags.get(tag)
                if auxValue != None:
                    # d.update({tag: toList[i].timestamp})        
                    d[tag] = toList[i].timestamp
        
        for x, y in d.items():
            print(x, y)
        print("\n")
        # sl = sorted(d.items(), key=lambda x:x[1])
        # sd = dict(sl)        
        # ssd = json.dumps(sd)        
        # queueClassRace.put(ssd)        
        sc = json.dumps(d)        
        queueClassRace.put(sc)
        contadorVoltas += 1
        # print("COMPLETA = ", contadorVoltas, "\n")        
    endClassRace = True
    contadorVoltas = 0        
    # print("ACABOU classRAce LOOP")


def comentario():    
    print()

def comentario2():
    # def setGlobals(config_sensor):
    #     global portaSerial
    #     global baudrate    
    #     global power
    #     global regiao    
    #     global antena
    #     global protocolo
    #     global reader
    #     portaSerial = config_sensor["portaSerial"]
    #     baudrate = config_sensor["baudrate"]
    #     regiao = config_sensor["regiao"]
    #     # antena = config_sensor["antena"]
    #     # protocolo = config_sensor["protocolo"]
    #     power = int(config_sensor["power"])
    #     reader = mercury.Reader(portaSerial, baudrate=baudrate)
    #     reader.set_region(regiao)
    #     reader.set_read_plan([1], "GEN2", read_power=power)    
    print()

def recebeConfiguracao(objJson):
    global portaSerial
    global baudrate    
    global power
    global regiao    
    global antena
    global protocolo
    global reader
    portaSerial = objJson["portaSerial"]
    baudrate = objJson["baudrate"]
    regiao = objJson["regiao"]
    # antena = objJson["antena"]
    # protocolo = objJson["protocolo"]
    power = int(objJson["power"])
    reader = mercury.Reader(portaSerial, baudrate=baudrate)
    reader.set_region(regiao)
    reader.set_read_plan([1], "GEN2", read_power=power)    
    with open('copia.json', 'w') as json_file:
        json.dump(objJson, json_file, indent=4)
    print(objJson)


def sendTags():
    global reader
    tagList = []    
    # tagsString = ""

    epcs = map(lambda l: l.epc, reader.read())
    toList = list(epcs)
    size = len(toList)
    for i in range(size):
        # s = "\'" + lista[i].decode("utf-8") + "\'"
        s = toList[i].decode("utf-8")
        tagList.append(s)        
        print(s)

    stringFormatada="{"
    for i in range(size):
        stringFormatada += "\"" + tagList[i] + "\""
        if i+1 < size:
            stringFormatada += ","
    stringFormatada+="}"
    print(stringFormatada)
    with open('et.json', 'w') as json_file:
        json.dump(stringFormatada, json_file, indent=4)        
        print(stringFormatada)
    
    print("salvou")
    # tagsString = json.dumps(tagList)

    print("tagsString")
    
    while not ct(DNSname):
        print("servidor foi desconectado")
    Client.send(stringFormatada.encode())
    print(stringFormatada)


# reader = mercury.Reader("tmr:///dev/ttyUSB0", baudrate=115200)
# reader.set_region("NA2")
# reader.set_read_plan([1], "GEN2", read_power=1500)
# reader = mercury.Reader(portaSerial, baudrate=baudrate)
# reader.set_region(regiao)
# reader.set_read_plan([1], "GEN2", read_power=power)

while True:    
    Client, address = ServerSocket.accept()    
    print('Connected to: ' + address[0] + ':' + str(address[1]))
    # print(address)
    # start_new_thread(threaded_client, (Client, ))
    # if (type(Client) == socket.socket) and (type(address) == tuple):
        # print("é isso ai meu rey")
    _thread.start_new_thread(threaded_client, (Client, ))    
    ThreadCount += 1
    print('Thread Number: ' + str(ThreadCount))
ServerSocket.close()
