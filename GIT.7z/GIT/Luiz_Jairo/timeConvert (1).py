
from datetime import datetime
import time

# nowtimestamp = datetime.timestamp(datetime.now())
# now = datetime.now()
# print(now)
# print(now.strftime('%H:%M'))
# print(now.strftime('%M:%S:%f'))
# timestamp = datetime.timestamp(now)
# print("timestamp =", timestamp)


# mt1 = 0.054837942123413086
# mt2 = 0.05087113380432129
# mt3 = 0.0548710823059082

# print(type(mt3))

# dt = datetime.fromtimestamp(mt1)
# tmsm = dt.strftime('%M:%S:%f')
# print(tmsm)

# print("TUDO JUNTO")
# print(datetime.fromtimestamp(mt2).strftime('%M:%S:%f'))
# print("TUDO JUNTO")
# print(datetime.fromtimestamp(mt3).strftime('%M:%S:%f'))

# # print(str(datetime.fromtimestamp(mt1)))
# # print(type(now.strftime('%M:%S:%f')))

# print(type(datetime.fromtimestamp(mt3).strftime('%M:%S:%f')))

# largada = 1618758528.874054
largada = 1618758529.221
# y1 = 1618758528.966
# y2 = 1618758529.288
# y3 = 1618758529.321
y3 = 1618758560.321

# print(y1 - largada)
# print(y2 - largada)
print(y3 - largada)
if(y3 - largada) > 30:
    print("FUNFA")    
    print("y3 - largada = ", y3 - largada)
    print("datetime y3 = ", datetime.fromtimestamp(float(y3)))
    print("DT largada  = ", datetime.fromtimestamp(float(largada)))
    dtY3 = datetime.fromtimestamp(float(y3))
    dtL = datetime.fromtimestamp(float(largada))
    hmsmY3 = dtY3.strftime('%M:%S:%f')
    hmsmL = dtL.strftime('%M:%S:%f')
    print("y3 segundos/milisegundos = ", hmsmY3)
    print("Largada segun/miliseguns = ", hmsmL)

# print(datetime.fromtimestamp(float(y1)))
# print(type(datetime.fromtimestamp(float(y1))))

# dt = datetime.fromtimestamp(float(y1))

# hmsm = dt.strftime('%M:%S:%f')
# print(hmsm)
# print(type(hmsm))