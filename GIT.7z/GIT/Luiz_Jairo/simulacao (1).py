from datetime import datetime
import time
y3 = 0.0
largada = 0.0

def retornaEpc(lista, epc):
    contador = 0
    for i in range(len(lista)):
        dicionario = lista[i]    
        dados_json = json.loads(dicionario)
        if (dados_json.get("TAG") == epc):
            return lista[i]
        else:
            return None

# largada = datetime.timestamp(datetime.now())
largada = 0.0
tempoMinimo = 10.0
contadorVoltasCarro1 = 0
contadorVoltasCarro2 = 0
contadorVoltasCarro3 = 0

c1 = "epc1"
c2 = "epc2"
c3 = "epc3"
ts1 = 11.0
ts2 = 12.0
ts3 = 13.0

def callBackRead(epc, timestamp):
    global largada    
    global tempoMinimo
    global contadorVoltasCarro1, contadorVoltasCarro2, contadorVoltasCarro3
    # tag = epc.decode("utf-8")
    tag = epc
    if(tag == "epc1"):
        if(timestamp - largada > tempoMinimo):            
            contadorVoltasCarro1 +=1
            print(tag, timestamp, contadorVoltasCarro1)
    if(tag == "epc2"):
        if(timestamp - largada > tempoMinimo):            
            contadorVoltasCarro2 +=1
            print(tag, timestamp, contadorVoltasCarro2)
    if(tag == "epc3"):
        if(timestamp - largada > tempoMinimo):            
            contadorVoltasCarro3 +=1
            print(tag, timestamp, contadorVoltasCarro3)
callBackRead(c1, ts1)
callBackRead(c2, ts2)
callBackRead(c3, ts3)
ts1 = 1.0
ts2 = 2.0
ts3 = 3.0
callBackRead(c1, ts1)
callBackRead(c2, ts2)
callBackRead(c3, ts3)
ts1 = 1.0
ts2 = 20.0
ts3 = 3.0
callBackRead(c1, ts1)
callBackRead(c2, ts2)
callBackRead(c3, ts3)