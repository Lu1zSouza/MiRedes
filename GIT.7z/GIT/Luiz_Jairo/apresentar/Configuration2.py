# -*- coding: utf-8 -*-
#!/usr/bin/env python3
# https://www.devmedia.com.br/tkinter-interfaces-graficas-em-python/33956
from tkinter import Tk, Frame, Pack, Label, Button, Entry, RIGHT, LEFT
import json

class Configuration2:
    def __init__(self, master=None): 

        self.c1 = Frame(master) # LABEL SERVIDOR
        # self.c1["pady"] = 10
        self.fontePadrao = ("Arial", "10")
        self.c1.pack()

        self.c2 = Frame(master) # LABEL AND ENTRY IP/DNS
        # self.c2["padx"] = 20
        self.c2.pack()

        self.c3 = Frame(master) # LABEL AND ENTRY PORTA
        # self.c3["padx"] = 20
        self.c3.pack()        

        self.c4 = Frame(master) # LABEL SENSOR  
        # self.c4["pady"] = 20
        self.c4.pack()

        self.c5 = Frame(master)
        # self.c5["pady"] = 20
        self.c5.pack()

        self.c6 = Frame(master)
        # self.c6["pady"] = 20
        self.c6.pack()

        self.c7 = Frame(master)
        # self.c7["pady"] = 20
        self.c7.pack()

        self.c8 = Frame(master)
        # self.c8["pady"] = 20
        self.c8.pack()

        self.c9 = Frame(master)
        # self.c9["pady"] = 20
        self.c9.pack()        

        self.servidor = Label(self.c1, text="Configuração do Servidor")
        self.servidor["font"] = ("Arial", "10", "bold")
        self.servidor.pack()        

        self.dnsipLabel = Label(self.c2,text="IP/DNS", font=self.fontePadrao)
        self.dnsipLabel.pack(side=LEFT)

        self.dnsip = Entry(self.c2)
        self.dnsip["width"] = 30
        self.dnsip["font"] = self.fontePadrao
        self.dnsip.insert(0, 'augusto.ddns.net')
        self.dnsip.pack(side=LEFT)

        self.portaLabel = Label(self.c3, text="PORTA", font=self.fontePadrao)
        self.portaLabel.pack(side=LEFT)

        self.porta = Entry(self.c3)
        self.porta["width"] = 30
        self.porta["font"] = self.fontePadrao
        self.porta.insert(0, 5022)
        # self.porta["show"] = "*"
        self.porta.pack(side=LEFT)

        self.sensor = Label(self.c4, text="Configuração do Sensor RFID")
        self.sensor["font"] = ("Arial", "10", "bold")
        self.sensor.pack()

        self.interfaceLabel = Label(self.c5, text="Interface", font=self.fontePadrao)
        self.interfaceLabel.pack(side=LEFT)

        self.interface = Entry(self.c5)
        self.interface["width"] = 30
        self.interface["font"] = self.fontePadrao
        self.interface.insert(0, "tmr:///dev/ttyUSB0")
        # self.porta["show"] = "*"
        self.interface.pack(side=LEFT)

        self.baud_rateLabel = Label(self.c6, text="Baud Rate", font=self.fontePadrao)
        self.baud_rateLabel.pack(side=LEFT)

        self.baud_rate = Entry(self.c6)
        self.baud_rate["width"] = 30
        self.baud_rate["font"] = self.fontePadrao
        self.baud_rate.insert(0, 115200)
        # self.porta["show"] = "*"
        self.baud_rate.pack(side=LEFT)

        self.read_powerLabel = Label(self.c7, text="Read Power", font=self.fontePadrao)
        self.read_powerLabel.pack(side=LEFT)

        self.read_power = Entry(self.c7)
        self.read_power["width"] = 30
        self.read_power["font"] = self.fontePadrao
        self.read_power.insert(0, 1500)
        # self.porta["show"] = "*"
        self.read_power.pack(side=LEFT)

        self.read_powerLabel = Label(self.c8, text="Region", font=self.fontePadrao)
        self.read_powerLabel.pack(side=LEFT)

        self.region = Entry(self.c8)
        self.region["width"] = 30
        self.region["font"] = self.fontePadrao
        self.region.insert(0, "NA2")
        # self.porta["show"] = "*"
        self.region.pack(side=LEFT)

        self.gravar = Button(self.c9)
        self.gravar["text"] = "Record"
        self.gravar["font"] = ("Calibri", "8")
        self.gravar["width"] = 12
        self.gravar["command"] = self.setRecord
        self.gravar.pack()

        self.mensagem = Label(self.c9, text="", font=self.fontePadrao)
        self.mensagem.pack()

    def setRecord(self):
        ip = self.dnsip.get()
        port = self.porta.get()
        itfc = self.interface.get()
        baudrate = self.baud_rate.get()
        readpower = self.read_power.get()
        rgn = self.region.get()
        # legoJSON = {"Usuario": usuario, "Senha": senha}
        # legoJSON = "{" + "\"IPorDNS\"" + ": " + "\"" + ip + "\"" + ", " + "\"Port\"" + ": " + port + "}"

        legoJSON = "{" + "\"METODO\"" + ": " + "\"POST\"" + ", " + "\"URL\"" + ": " + "\"configLeitor\"" + ", " + "\"IPorDNS\"" + ": " + "\"" + ip + "\"" + "," + "\"Port\"" + ": " + port + "," + "\"portaSerial\"" + ": " + "\"" + itfc + "\"" + "," + "\"baudrate\"" + ": " + baudrate + "," + "\"power\"" + ": " + readpower + "," + "\"regiao\"" + ": " + "\"" + rgn + "\"" + "}"
        # print(legoJSON)
        # print("\n")


        configs_json = json.loads(legoJSON)
        # with open('config.json', 'w') as json_file:
        with open('sensorConfigs.json', 'w') as json_file:
            json.dump(configs_json, json_file, indent=4)        
        # self.mensagem["text"] = "Configurações foram salvas no arquivo 'config.JSON'"        
        self.mensagem["text"] = "Configurações foram salvas"        
        # self.mensagem["text"] = legoJSON
        print(configs_json)
