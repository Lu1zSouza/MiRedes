from flask import Flask, render_template # Importa a biblioteca
import os, time
from datetime import datetime
import json
import webbrowser
app = Flask(__name__) # Inicializa a aplicação
@app.route('/') # Cria uma rota 
def main():
  # resultado = None
  # media = None
  while True:

    
    with open('fase.json', 'r') as json_file:
      dados = json.load(json_file)

      if dados["class"] == "True" and dados["race"] == "False":
        qualifying = True
        grandPrix = False
      if dados["class"] == "False" and dados["race"] == "True":
        qualifying = False
        grandPrix = True

    print("COMEÇOU = ", datetime.now())
    with open('voltaAutalClassificacao.json', 'r') as json_file:
      dados = json.load(json_file)
    # print(dados)
    # print(type(dados))
    sortedList = sorted(dados.items(), key=lambda x:x[1])
    sortedDict = dict(sortedList)           

    stringFormatada = "\n"
    position = 1

    for x, y in sortedDict.items():
      if x == "Referencia":
        continue
      # stringFormatada += x + " = " + str(y) + " Seg/milisegundos" + "\n"
      dt = datetime.fromtimestamp(float(y))
      hmsm = dt.strftime('%M:%S:%f')
      stringFormatada +="     " + str(position) + "º    | " + x + " | " + hmsm + " Min : Seg : milis" + "\n"
      position += 1
      # stringFormatada += x + " = " + str(datetime.fromtimestamp(y).strftime('%M:%S:%f')) + " MM:SS:mmmmmm" + "\n"
      # stringFormatada += x + " = " + datetime.fromtimestamp(y).strftime('%M:%S:%f') + " MM:SS:mmmmmm" + "\n"
      # print(x, y)    
    print("TERMINOU = ", datetime.now())
    # time.sleep(5)  
    # classification = True
    # race = False
    
    return render_template('index.html', data=stringFormatada, classification=qualifying, race=grandPrix)
    
if __name__ == '__main__':  
  # The reloader has not yet run - open the browser
  if not os.environ.get("WERKZEUG_RUN_MAIN"):
      webbrowser.open_new('http://127.0.0.1:5000/')

  # Otherwise, continue as normal
  app.run(host="127.0.0.1", port=5000, debug=True)
  
  # app.run() # Executa a aplicação
