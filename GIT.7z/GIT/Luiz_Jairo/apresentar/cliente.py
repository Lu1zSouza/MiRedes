# -*- coding: utf-8 -*-
#!/usr/bin/env python3
from tkinter import Tk, Frame, Pack, Label, Button, Entry, RIGHT, LEFT, Toplevel, Text, END, INSERT
import platform, subprocess, socket, sys, time, json
from Configuration2 import Configuration2
from RestUI import RestUI
from RaceWindow import RaceWindow
import _thread, os
import threading
# import queue
# voltasClassificacao = queue.Queue(maxsize=10)
socket_server = socket.socket()
DNSname = "augusto.ddns.net"
carList = []
terminou = False
root = None
qtdVoltasI = 0
contadorVoltas = 0
lapsClass = False
lapsRace = False

def ping(host_or_ip, packets=1, timeout=1000):    
    if platform.system().lower() == 'windows':
        command = ['ping', '-n', str(packets), '-w', str(timeout), host_or_ip]        
        result = subprocess.run(command, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, creationflags=0x08000000)        
        return result.returncode == 0 and b'TTL=' in result.stdout
    else:
        command = ['ping', '-c', str(packets), '-w', str(timeout), host_or_ip]        
        result = subprocess.run(command, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return result.returncode == 0

def conectaServidor():
    # global serverConected
    # print(serverConected)
    with open('sensorConfigs.json', 'r') as json_file:
            dados = json.load(json_file)    
    sport = dados["Port"]
    server_host = dados["IPorDNS"]
    print(server_host)
    print(sport)    
    while not ping(DNSname):
        print("sem conexão com servidor")
    socket_server.connect((server_host, sport))    
    print('CONECTADO AO SERVIDOR')

def openConfiguration():    
    configWindow = Tk()
    Configuration2(configWindow)
    configWindow.mainloop()

def enviarConfiguracao():
    with open('sensorConfigs.json', 'r') as json_file:
        dados = json.load(json_file)    
    de = json.dumps(dados)
    while not ping(DNSname):
        print("sem conexão com servidor")
    socket_server.send(de.encode())    
    print('configurações foram enviadas')

def listaEpcTags():
    requestTags = {"METODO": "GET", "URL": "retornaEPC"}
    reqTS = json.dumps(requestTags)
    while not ping(DNSname):
        print("sem conexão com servidor")
    socket_server.send(reqTS.encode())
    tagsString = (socket_server.recv(1024)).decode()    
    print(tagsString)
    # tagsList = json.loads(tagsString)
    # print(tagsList)
    # with open('epcTags.json', 'w') as json_file:
    #     json.dump(tagsList, json_file, indent=4)

def setClass():
    global lapsClass
    lapsClass = True
    fase = {"class":"True", "race":"False"}
    with open('fase.json', 'w') as json_file:
        json.dump(fase, json_file, indent=4)
    laps(fase)

def setRace():
    global lapsRace
    lapsRace = True
    fase = {"class":"False", "race":"True"}
    with open('fase.json', 'w') as json_file:
        json.dump(fase, json_file, indent=4)
    laps(fase)

def laps(fase):
        
    global qtdVoltasI
    global contadorVoltas    
    qtdVoltasS = qtdVoltasE.get()
    qtdVoltasI = int(qtdVoltasS)
    tmVoltasS = tmVoltasE.get()
    # tmVoltasI = int(tmVoltasS)
    contadorVoltas = 0
    print(qtdVoltasI)

    requestServer=""

    if fase["class"] == 'True' and fase["race"] == "False":
        # requestClass = 'GET/autorama/class/'+qtdVoltasS
        zerado = {"CAR": 0.0}
        with open('voltaAutalClassificacao.json', 'w') as json_file:
            json.dump(zerado, json_file, indent=4)
        # subprocess.call(['python', 'main.py'])
        z = "atualizado"
        _thread.start_new_thread(threadBrowser, (z, ))
        requestClass = {"METODO": "GET", "URL": "comecaQual", "qtdVoltas": qtdVoltasS, "tmVoltas": tmVoltasS}
        requestServer = json.dumps(requestClass)
        
    if  fase["class"] == "False" and fase["race"] == 'True':
        # requestClass = 'GET/autorama/race/'+qtdVoltasS
        # zerado = {"CAR": 0.0}
        # with open('voltaAutalClassificacao.json', 'w') as json_file:
        #     json.dump(zerado, json_file, indent=4)
        # subprocess.call(['python', 'main.py'])
        z = "atualizado"
        _thread.start_new_thread(threadBrowser, (z, ))
        requestRace = {"METODO": "GET", "URL": "comecaCorr", "qtdVoltas": qtdVoltasS, "tmVoltas": tmVoltasS}
        requestServer = json.dumps(requestRace)        

    while not ping(DNSname):
        print("sem conexão com servidor")
    # socket_server.send(qtdVoltasS.encode())
    socket_server.send(requestServer.encode())

    melhoresTempos={}
    temposVoltaAtual={}       
    largada = 0 
    tempo = 0
    while contadorVoltas < qtdVoltasI:
        classString = (socket_server.recv(1024)).decode()        
        cd = json.loads(classString)
        print(cd)                
        if contadorVoltas == 0:        
            for x, y in cd.items():
                if x == "Referencia":                                    
                    largada = y
                    continue                
                tempo = y - largada
                melhoresTempos[x] = tempo
                temposVoltaAtual[x] = tempo
            with open('voltaAutalClassificacao.json', 'w') as json_file:
                json.dump(temposVoltaAtual, json_file, indent=4)                
        else:
            for x, y in cd.items():
                if x == "Referencia":                
                    largada = y
                    continue                
                # tempo = y - largada
                # temposVoltaAtual[x] = tempo
                # if (tempo) < melhoresTempos.get(x):
                #     melhoresTempos.update({x: tempo})
                auxValue = melhoresTempos.get(x)
                if auxValue != None:
                    tempo = y - largada
                    temposVoltaAtual[x] = tempo
                    if (tempo) < auxValue:
                        melhoresTempos.update({x: tempo})
            with open('voltaAutalClassificacao.json', 'w') as json_file:
                json.dump(temposVoltaAtual, json_file, indent=4)        
        contadorVoltas += 1        
    print("acabou classificação")
    time.sleep(5)
    previa = {"contabilizando melhores tempos": 0.0}
    with open('voltaAutalClassificacao.json', 'w') as json_file:
        json.dump(previa, json_file, indent=4)
    time.sleep(5)
    with open('voltaAutalClassificacao.json', 'w') as json_file:
        json.dump(melhoresTempos, json_file, indent=4)


def threadBrowser(algumacoisa):
    # def threadBrowser():
    subprocess.call(['python', 'main.py'])
    print(algumacoisa)

def praversevai(stringalgumacoisa):
    global carList
    global terminou
    while True:
        if terminou:
            print("FUNFA")
            print(carList)
            print(stringalgumacoisa)

# z = "atualizado"
# _thread.start_new_thread(updateCarLabel, (z, ))
# _thread.start_new_thread(root.after, (1000, updateCarLabel(z)))
# _thread.start_new_thread(praversevai, ("CABÔ", ))
# threadBrowser()

root = Tk()
root.geometry('400x300')
buttonConectaServidor = Button(root, text="conectar ao servidor", command=conectaServidor)
buttonConectaServidor.pack()
buttonDefinirConfiguracao = Button(root, text="definir configurações", command=openConfiguration)
buttonDefinirConfiguracao.pack()
buttonEnviarConfiguracao = Button(root, text="enviar configurações", command=enviarConfiguracao)
buttonEnviarConfiguracao.pack()
buttonGetAllTags = Button(root, text="get ALL tags", command=listaEpcTags)
buttonGetAllTags.pack()
qtdVoltasL = Label(root, text="quantas voltas?")
qtdVoltasL["font"] = ("Arial", "10", "bold")
qtdVoltasL.pack()
qtdVoltasE = Entry(root)
qtdVoltasE.insert(0, '3')
qtdVoltasE.pack()

tmVoltasL = Label(root, text="Tempo mínimo da voltas:")
tmVoltasL["font"] = ("Arial", "10", "bold")
tmVoltasL.pack()
tmVoltasE = Entry(root)
tmVoltasE.insert(0, '15000')
tmVoltasE.pack()

buttonClassification = Button(root, text="Classificação", command=setClass)
buttonClassification.pack()
buttonRace = Button(root, text="Corrida", command=setRace)
buttonRace.pack()
root.mainloop()