# -*- coding: utf-8 -*-
#!/usr/bin/env python3
from __future__ import print_function
import platform, subprocess, socket, sys, os, time, json
from datetime import datetime
import mercury
import _thread
import threading
import queue

dicionario = {}
podeLer = False
comecaDarVoltas = False

# def qual(voltas, tempoMinimo):
#     global podeLer
#     global dicionario
#     global comecaDarVoltas

#     while contador < voltas: # VOLTAS tem que ser GLOBAL
#         comecaDarVoltas = True
#         time.sleep(tempoMinimo)

#         if podeLer:
#             podeLer = False
#             # THREAD LEITOR
#             podeLer = True
#         else:
#             podeLer = True
#                             # 1 -> 2 -> 3 -> 4 -> ... -> FINISH
#         time.sleep(tempoMinimo)
#         podeLer = False
#         # THREAD LEITOR
#         podeLer = True
#         contador += 1 

#     comecaDarVoltas = False
#     podeLer = False

def retornaNumeroDeVoltas(lista, epc):
    contador = 0
    for i in range(len(lista)):
        dicionario = lista[i]    
        dados_json = json.loads(dicionario)
        if (dados_json.get("TAG") == epc):
            contador += 1
    if (contador > 0):
        contador += 1
    else:
        contador = 1
    return contador

def retornaTimestampAnterior(lista, epc):
    aux = 0
    nv = 0
    for i in range(len(lista)):
        dicionario = lista[i]
        dados_json = json.loads(dicionario)
        if (dados_json.get("TAG") == epc):
            aux = int(dados_json.get("numeroVolta"))
            if aux > nv:
                nv = aux
    for i in range(len(lista)):
        dicionario = lista[i]
        dados_json = json.loads(dicionario)
        if (dados_json.get("TAG") == epc) and (dados_json.get("numeroVolta") == str(nv)):
            return float(dados_json["TIMESTAMP"])


largada = datetime.timestamp(datetime.now())
listaCarrosVoltas = []

def callBackRead(epc, timestamp):    
    global largada
    global listaCarrosVoltas
    global tempoMinimo
    global contadorVoltas
    tag = epc.decode("utf-8")    
    if contadorVoltas == 0:
        if((timestamp - largada) > tempoMinimo):
            numeroDaVolta = retornaNumeroDeVoltas(listaCarrosVoltas, tag)        
            legoJSON = "{" + "\"TAG\"" + ": " + "\"" + tag + "\"" + ", " + "\"TIMESTAMP\"" + ": "  + "\"" + timestamp + "\""  + ", " + "\"numeroVolta\"" + ": " + "\"" + numeroDaVolta + "\"" + "}"
            listaCarrosVoltas.append(legoJSON)  
            contadorVoltas += 1      
    else:
        # if (timestamp - timestampVoltaAnterior) > tempoMinimo:
        if (timestamp - retornaTimestampAnterior(listaCarrosVoltas, epc)) > tempoMinimo:
            numeroDaVolta = retornaNumeroDeVoltas(listaCarrosVoltas, tag)        
            legoJSON = "{" + "\"TAG\"" + ": " + "\"" + tag + "\"" + ", " + "\"TIMESTAMP\"" + ": "  + "\"" + timestamp + "\""  + ", " + "\"numeroVolta\"" + ": " + "\"" + numeroDaVolta + "\"" + "}"
            listaCarrosVoltas.append(legoJSON)



    stringJSON = json.dumps(dicionario)
    queueClassRace.put(stringJSON)
    dicionario.clear()



def qual(voltas, tempoMinimo):
    global podeLer
    global dicionario
    global comecaDarVoltas

    while contador < voltas: # VOLTAS tem que ser GLOBAL
        comecaDarVoltas = True        
        podeLer = True


podeLer = False
comecaDarVoltas = False

def continuousReading(teste):
    global podeLer
    global dicionario
    global comecaDarVoltas
    global contador

    liberado = False

    while True:
        # if podeLer and comecaDarVoltas:
        if contador > 0:
            reader.start_reading(lambda tag: continuousReading(tag.epc, tag.timestamp))    
            time.sleep(0.250)    
            reader.stop_reading()
            # liberado = True
        else:

            print(d)
            print("\n")
            print(dicionario)
            print("\n")
            # if podeLer and comecaDarVoltas:
            if (podeLer == False) and (liberado == True):
                stringJSON = json.dumps(dicionario)
                queueClassRace.put(stringJSON)
                dicionario.clear()
                podeLer = True
                liberado = False